from django.contrib import admin
from .models import products,carasouelimage
# Register your models here.
admin.site.register(products)
admin.site.register(carasouelimage)