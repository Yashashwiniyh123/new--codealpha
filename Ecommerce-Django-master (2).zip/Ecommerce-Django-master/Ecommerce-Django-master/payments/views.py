from django.shortcuts import render, redirect
from home.models import products
from .models import userpayments
from django.contrib import messages
from django.http import JsonResponse
from accounts.models import user as myuser
from django.contrib.auth.decorators import login_required
import json

@login_required
def payments(request, payment_id):
    try:
        current_user = myuser.objects.get(id=request.user.id)
        my_product = products.objects.get(id=payment_id)

        # Prevent duplicate cart item
        if userpayments.objects.filter(userid=current_user.id, product_id=my_product.id, cart=True).exists():
            messages.info(request, "Product already in cart.")
            return redirect("/Cart")

        user_cart = userpayments(
            userid=current_user.id,
            name=current_user.name,
            username=current_user.username,
            address=current_user.address,
            cart=True,
            wishlist=False,
            phone=current_user.phone,
            product_name=my_product.name,
            product_category=my_product.category,
            price=my_product.price,
            product_id=my_product.id,
            tax=my_product.tax,
            discount=my_product.discount,
            available=my_product.available,
            quantity=1,
        )
        user_cart.save()
        return redirect("/Cart")

    except myuser.DoesNotExist:
        messages.error(request, "User not found. Please log in.")
        return redirect("/")
    except products.DoesNotExist:
        messages.error(request, "Product not found.")
        return redirect("/")

@login_required
def wishlist(request, id):
    try:
        current_user = myuser.objects.get(id=request.user.id)
        my_product = products.objects.get(id=id)

        # Prevent duplicate wishlist item
        if userpayments.objects.filter(userid=current_user.id, product_id=my_product.id, wishlist=True).exists():
            messages.info(request, "Product already in wishlist.")
            return redirect("/wishlistView")

        user_cart = userpayments(
            userid=current_user.id,
            name=current_user.name,
            username=current_user.username,
            address=current_user.address,
            wishlist=True,
            cart=False,
            phone=current_user.phone,
            product_id=my_product.id,
            product_name=my_product.name,
            product_category=my_product.category,
            price=my_product.price,
            tax=my_product.tax,
            discount=my_product.discount,
            available=my_product.available,
            quantity=1,
        )
        user_cart.save()
        return redirect("/wishlistView")

    except myuser.DoesNotExist:
        messages.error(request, "User not found.")
        return redirect("/")
    except products.DoesNotExist:
        messages.error(request, "Product not found.")
        return redirect("/")

@login_required
def cart(request):
    try:
        cart_view = userpayments.objects.filter(userid=request.user.id, cart=True)
        return render(request, "HTML/cart.html", {"cart_view": cart_view})
    except Exception as e:
        messages.error(request, f"Error: {str(e)}")
        return redirect("/")

@login_required
def wishlistView(request):
    try:
        wishlist_view = userpayments.objects.filter(userid=request.user.id, wishlist=True)
        return render(request, "HTML/wishlist.html", {"wishlist_view": wishlist_view})
    except Exception as e:
        messages.error(request, f"Error: {str(e)}")
        return redirect("/")

@login_required
def deleteitem(request, id):
    try:
        usercart = userpayments.objects.get(id=id, userid=request.user.id, cart=True)
        usercart.delete()
        return redirect("/Cart")
    except userpayments.DoesNotExist:
        messages.error(request, "Cart item not found.")
        return redirect("/Cart")

@login_required
def wishlistdeleteitem(request, id):
    try:
        usercart = userpayments.objects.get(id=id, userid=request.user.id, wishlist=True)
        usercart.delete()
        return redirect("/wishlistView")
    except userpayments.DoesNotExist:
        messages.error(request, "Wishlist item not found.")
        return redirect("/wishlistView")

@login_required
def paymentpage(request):
    cart_view = userpayments.objects.filter(userid=request.user.id, cart=True)
    if request.method == "POST":
        for item in cart_view:
            quantity = request.POST.get(f"quantity{item.id}")
            if quantity and quantity.isdigit():
                item.quantity = int(quantity)
                item.save()

    grandtotal = sum(int(i.price) * int(i.quantity) for i in cart_view)
    return render(request, "HTML/paypal.html", {"grandtotal": grandtotal})

@login_required
def ordercomplete(request):
    try:
        body = json.loads(request.body)
        transaction_id = body.get("transaction_id")
        if not transaction_id:
            return JsonResponse({'error': 'Missing transaction_id'}, status=400)

        cart_views = userpayments.objects.filter(userid=request.user.id, cart=True)

        for cart_view in cart_views:
            cart_view.paymentid = transaction_id
            cart_view.paymentstatus = True
            cart_view.cart = False  # Remove from cart
            cart_view.save()

        return JsonResponse({'message': 'Order completed'})
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid request format'}, status=400)

@login_required
def myorders(request):
    cart_views = userpayments.objects.filter(userid=request.user.id, paymentstatus=True)
    prices = productprice(cart_views)
    return render(request, "HTML/myorders.html", {"cart_views": cart_views, "prices": prices})

def productprice(cart_views):
    return {
        i.product_id: int(i.quantity) * int(i.price)
        for i in cart_views
    }
